"use client";

import { useCart } from "@/hooks/useCart";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ShoppingCartIcon, ChevronRight } from "lucide-react";
import Cart from "./Cart";

export default function StickyCartHeader() {
  const { totalItems, cartTotal } = useCart();

  if (totalItems === 0) {
    return null;
  }

  return (
    <div className="lg:hidden fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-auto">
      <Sheet>
        <SheetTrigger asChild>
          <button className="flex items-center justify-between gap-4 rounded-full bg-accent text-accent-foreground shadow-lg px-4 py-3 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3">
              <ShoppingCartIcon className="h-6 w-6" />
              <div>
                <p className="font-bold text-lg leading-tight">View Cart</p>
                <p className="text-sm">{totalItems} item{totalItems > 1 ? 's' : ''}</p>
              </div>
            </div>
            <ChevronRight className="h-6 w-6" />
          </button>
        </SheetTrigger>
        <SheetContent className="w-full sm:max-w-md flex flex-col p-0">
          <Cart />
        </SheetContent>
      </Sheet>
    </div>
  );
}