"use server";
import { getDeliveryUpdate, GetDeliveryUpdateInput } from '@/ai/flows/real-time-delivery-updates';
import type { GetDeliveryUpdateOutput } from '@/ai/flows/real-time-delivery-updates';

export async function fetchDeliveryUpdate(input: GetDeliveryUpdateInput): Promise<{success: boolean, data?: GetDeliveryUpdateOutput, error?: string}> {
    try {
        const result = await getDeliveryUpdate(input);
        return { success: true, data: result };
    } catch (error) {
        console.error("Error fetching delivery update:", error);
        if (error instanceof Error) {
            return { success: false, error: error.message };
        }
        return { success: false, error: "Failed to fetch delivery update." };
    }
}
