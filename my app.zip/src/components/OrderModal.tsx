
"use client";

import { useState, useMemo } from 'react';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MINIMUM_ORDER_VALUE = 99;
const DELIVERY_CHARGE = 20;
const HANDLING_CHARGE = 5;

export default function OrderModal({ isOpen, onClose }: OrderModalProps) {
  const { cartItems, cartTotal, clearCart } = useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [landmark, setLandmark] = useState('');

  const deliveryCharge = useMemo(() => (cartTotal > 0 && cartTotal < MINIMUM_ORDER_VALUE ? DELIVERY_CHARGE : 0), [cartTotal]);
  const handlingCharge = useMemo(() => (cartTotal >= MINIMUM_ORDER_VALUE ? HANDLING_CHARGE : 0), [cartTotal]);
  const grandTotal = useMemo(() => cartTotal + deliveryCharge + handlingCharge, [cartTotal, deliveryCharge, handlingCharge]);

  const handleConfirmOrder = () => {
    const orderDetails = cartItems.map(item => `${item.name} (x${item.quantity}) - ₹${(item.price * item.quantity).toFixed(2)}`).join('\n');
    const charges = `\n----------------------\nSubtotal: ₹${cartTotal.toFixed(2)}\nDelivery: ₹${deliveryCharge.toFixed(2)}\nHandling: ₹${handlingCharge.toFixed(2)}\n*Total: ₹${grandTotal.toFixed(2)}*`;
    const deliveryInfo = `\n----------------------\n*Delivery Details:*\nName: ${name}\nPhone: ${phone}\nLocation: ${location}\nLandmark: ${landmark || 'N/A'}`;
    
    const message = `*New Order Received!*\n\n*Items:*\n${orderDetails}${charges}${deliveryInfo}\n\n*Delivery in 15-20 minutes!*`;
    
    const whatsappUrl = `https://api.whatsapp.com/send?phone=918182820265&text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    
    clearCart();
    onClose();
  };

  const isFormValid = name.trim() !== '' && location.trim() !== '' && phone.trim() !== '';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Confirm Your Order</DialogTitle>
          <DialogDescription>
            Delivery in 15-20 minutes.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your name" />
          </div>
          <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Enter your phone number" />
          </div>
          <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Enter your delivery address" />
          </div>
          <div className="space-y-2">
              <Label htmlFor="landmark">Landmark (Optional)</Label>
              <Input id="landmark" value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="Nearby landmark" />
          </div>
          <Separator />
          <div className="max-h-[20vh] overflow-y-auto space-y-2 pr-2">
            {cartItems.map(item => (
              <div key={item.id} className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.quantity} x ₹{item.price.toFixed(2)}
                  </p>
                </div>
                <p className="font-semibold">₹{(item.quantity * item.price).toFixed(2)}</p>
              </div>
            ))}
          </div>
          <Separator />
           <div className="space-y-1">
             <div className="flex justify-between items-center text-sm">
              <p>Subtotal</p>
              <p>₹{cartTotal.toFixed(2)}</p>
            </div>
            <div className="flex justify-between items-center text-sm">
              <p>Delivery Charge</p>
              <p>₹{deliveryCharge.toFixed(2)}</p>
            </div>
             <div className="flex justify-between items-center text-sm">
              <p>Handling Charge</p>
              <p>₹{handlingCharge.toFixed(2)}</p>
            </div>
          </div>
          <Separator />
          <div className="flex justify-between items-center text-xl font-bold">
            <p>Grand Total</p>
            <p>₹{grandTotal.toFixed(2)}</p>
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" className="bg-accent hover:bg-accent/90 text-accent-foreground" onClick={handleConfirmOrder} disabled={!isFormValid}>
            Confirm &amp; Share on WhatsApp
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
