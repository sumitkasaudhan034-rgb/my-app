import Header from '@/components/Header';
import ProductList from '@/components/ProductList';
import Cart from '@/components/Cart';
import StickyCartHeader from '@/components/StickyCartHeader';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <div className="container mx-auto flex-grow p-4 md:p-6 lg:p-8">
        <div className="flex flex-col lg:flex-row lg:gap-8">
          <main className="lg:w-3/4 pb-20 lg:pb-0">
            <ProductList />
          </main>
          <aside className="hidden lg:block lg:w-1/4 mt-8 lg:mt-0">
            <div className="sticky top-24">
              <Cart />
            </div>
          </aside>
        </div>
      </div>
      <StickyCartHeader />
    </div>
  );
}