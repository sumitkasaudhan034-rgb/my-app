
"use client";

import { useState } from 'react';
import { useCart } from '@/hooks/useCart';
import CartItem from './CartItem';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ShoppingCart } from 'lucide-react';
import OrderModal from './OrderModal';

const MINIMUM_ORDER_VALUE = 99;
const DELIVERY_CHARGE = 20;
const HANDLING_CHARGE = 5;

export default function Cart() {
  const { cartItems, cartTotal, totalItems } = useCart();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const deliveryCharge = cartTotal > 0 && cartTotal < MINIMUM_ORDER_VALUE ? DELIVERY_CHARGE : 0;
  const handlingCharge = cartTotal >= MINIMUM_ORDER_VALUE ? HANDLING_CHARGE : 0;
  const grandTotal = cartTotal + deliveryCharge + handlingCharge;
  const canCheckout = cartTotal > 0;

  return (
    <>
      <Card className="shadow-lg lg:shadow-lg flex flex-col h-full lg:h-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart />
            Your Cart
            {totalItems > 0 && <span className="text-sm font-normal text-muted-foreground">({totalItems} items)</span>}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-grow overflow-y-auto">
          {cartItems.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">Your cart is empty.</p>
          ) : (
            <div className="space-y-4 max-h-[calc(100vh-350px)] lg:max-h-[40vh] pr-2">
              {cartItems.map(item => (
                <CartItem key={item.id} item={item} />
              ))}
            </div>
          )}
        </CardContent>
        {cartItems.length > 0 && (
          <CardFooter className="flex flex-col gap-4 mt-auto">
            <Separator />
            <div className="w-full flex justify-between items-center text-sm">
              <span>Subtotal</span>
              <span>₹{cartTotal.toFixed(2)}</span>
            </div>
            {deliveryCharge > 0 && (
               <div className="w-full flex justify-between items-center text-sm">
                <span>Delivery Charge</span>
                <span>₹{deliveryCharge.toFixed(2)}</span>
              </div>
            )}
             <div className="w-full flex justify-between items-center text-sm">
              <span>Handling Charge</span>
              <span>₹{handlingCharge.toFixed(2)}</span>
            </div>
            <Separator />
            <div className="w-full flex justify-between items-center text-lg font-bold">
              <span>Grand Total</span>
              <span>₹{grandTotal.toFixed(2)}</span>
            </div>
             {cartTotal < MINIMUM_ORDER_VALUE && (
              <p className="text-sm text-center text-destructive w-full">
                Add items worth ₹{(MINIMUM_ORDER_VALUE - cartTotal).toFixed(2)} more to save delivery charges.
              </p>
            )}
            <Button
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold text-lg py-6"
              onClick={() => setIsModalOpen(true)}
              disabled={!canCheckout}
            >
              Checkout
            </Button>
          </CardFooter>
        )}
      </Card>
      <OrderModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
