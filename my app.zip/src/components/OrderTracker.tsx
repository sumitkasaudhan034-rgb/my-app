"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { fetchDeliveryUpdate } from '@/app/track/actions';
import type { GetDeliveryUpdateOutput } from '@/ai/flows/real-time-delivery-updates';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { MapPin, AlertCircle, Loader2, Send } from 'lucide-react';
import Image from 'next/image';

const formSchema = z.object({
  orderId: z.string().min(1, "Order ID is required"),
  userAddress: z.string().min(1, "Your address is required"),
  deliveryVehicleId: z.string().min(1, "Delivery vehicle ID is required"),
});

type FormValues = z.infer<typeof formSchema>;

export default function OrderTracker() {
  const [update, setUpdate] = useState<GetDeliveryUpdateOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      orderId: 'ORD12345',
      userAddress: '123 Swift Lane, Bangalore',
      deliveryVehicleId: 'VHC67890',
    },
  });

  async function onSubmit(values: FormValues) {
    setIsLoading(true);
    setError(null);
    setUpdate(null);
    
    const result = await fetchDeliveryUpdate(values);

    if (result.success && result.data) {
      setUpdate(result.data);
    } else {
      setError(result.error || "An unknown error occurred.");
    }
    setIsLoading(false);
  }

  return (
    <div className="max-w-4xl mx-auto grid gap-8 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Track Your Delivery</CardTitle>
          <CardDescription>Enter your order details to get real-time updates.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="orderId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order ID</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., ORD12345" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="userAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Address</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 123 Swift Lane, Bangalore" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="deliveryVehicleId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Delivery Vehicle ID</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., VHC67890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Tracking...
                  </>
                ) : (
                  'Track Order'
                )}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      <div className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {update ? (
          <Card>
            <CardHeader>
              <CardTitle>Delivery Status</CardTitle>
              <CardDescription>Last updated just now.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative h-48 w-full rounded-lg overflow-hidden border">
                <Image src="https://picsum.photos/800/400" alt="Map view of delivery" fill className="object-cover" data-ai-hint="map delivery" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="font-bold text-lg">{update.status}</p>
                  <p className="text-sm">ETA: {update.estimatedArrivalTime}</p>
                </div>
              </div>
              <Alert>
                <Send className="h-4 w-4" />
                <AlertTitle>Update</AlertTitle>
                <AlertDescription>{update.notificationMessage}</AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        ) : (
           <Card className="flex flex-col items-center justify-center text-center h-full">
              <CardHeader>
                  <div className="mx-auto bg-secondary p-3 rounded-full">
                      <MapPin className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <CardTitle className="mt-4">Waiting for order details</CardTitle>
                  <CardDescription>Your delivery status will appear here.</CardDescription>
              </CardHeader>
            </Card>
        )}
      </div>
    </div>
  );
}
