import Link from 'next/link';
import { Package } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-card shadow-md sticky top-0 z-40">
      <div className="container mx-auto flex justify-between items-center p-4 md:p-6">
        <Link href="/" className="flex items-center gap-2">
          <Package className="w-8 h-8 text-primary" />
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">
            Shop Easy
          </h1>
        </Link>
      </div>
    </header>
  );
}
