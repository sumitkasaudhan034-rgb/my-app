"use client";

import { useState, useMemo } from 'react';
import { products, agencies } from '@/lib/products';
import ProductCard from './ProductCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Search } from 'lucide-react';

export default function ProductList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgency, setSelectedAgency] = useState('All');

  const filteredProducts = useMemo(() => {
    return products
      .filter(p => selectedAgency === 'All' || p.agency === selectedAgency)
      .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [searchTerm, selectedAgency]);

  return (
    <div>
      <div className="mb-8 p-6 bg-card rounded-lg shadow">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <Package className="w-12 h-12 text-primary hidden sm:block" />
          <div className='flex-grow'>
            <h2 className="text-4xl font-bold">Shop Easy</h2>
            <p className="text-muted-foreground mt-1">delivered in 15-20 minutes</p>
            <p className="text-muted-foreground">Order above ₹99 for free delivery</p>
          </div>
        </div>

        <div className="mt-6 text-sm text-muted-foreground text-center space-y-1">
          <p>Proprietor: Ravindra Kumar Kasaudhan</p>
          <p>Mob: 8182820265, 9651343956</p>
          <p className="text-xs">powered by sachin traders</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mt-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full"
            />
          </div>
          <Select value={selectedAgency} onValueChange={setSelectedAgency}>
            <SelectTrigger className="w-full md:w-[200px]">
              <SelectValue placeholder="Filter by agency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Agencies</SelectItem>
              {agencies.map(agency => (
                <SelectItem key={agency} value={agency}>{agency}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-card rounded-lg">
            <h3 className="text-xl font-semibold">No Products Found</h3>
            <p className="text-muted-foreground mt-2">Try adjusting your search or filter.</p>
        </div>
      )}
    </div>
  );
}
