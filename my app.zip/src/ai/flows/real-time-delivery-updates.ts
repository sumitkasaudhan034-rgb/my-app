'use server';
/**
 * @fileOverview This file defines a Genkit flow for providing real-time delivery updates with interactive maps and notifications.
 *
 * - getDeliveryUpdate - A function that gets real time delivery updates on order status.
 * - GetDeliveryUpdateInput - The input type for the getDeliveryUpdate function.
 * - GetDeliveryUpdateOutput - The return type for the getDeliveryUpdate function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GetDeliveryUpdateInputSchema = z.object({
  orderId: z.string().describe('The ID of the order to track.'),
  userAddress: z.string().describe('The delivery address of the user.'),
  deliveryVehicleId: z.string().describe('The ID of the delivery vehicle.'),
});
export type GetDeliveryUpdateInput = z.infer<typeof GetDeliveryUpdateInputSchema>;

const GetDeliveryUpdateOutputSchema = z.object({
  status: z.string().describe('The current status of the order (e.g., en route, delivered).'),
  estimatedArrivalTime: z.string().describe('The estimated time of arrival for the order.'),
  mapUrl: z.string().describe('A URL providing an interactive map showing the delivery progress.'),
  notificationMessage: z.string().describe('A message to display to the user with the latest update.'),
});
export type GetDeliveryUpdateOutput = z.infer<typeof GetDeliveryUpdateOutputSchema>;

export async function getDeliveryUpdate(input: GetDeliveryUpdateInput): Promise<GetDeliveryUpdateOutput> {
  return getDeliveryUpdateFlow(input);
}

const deliveryUpdatePrompt = ai.definePrompt({
  name: 'deliveryUpdatePrompt',
  input: {schema: GetDeliveryUpdateInputSchema},
  output: {schema: GetDeliveryUpdateOutputSchema},
  prompt: `You are a delivery update service.  Given the order ID {{orderId}}, the user's address {{userAddress}}, and the delivery vehicle ID {{deliveryVehicleId}}, provide real-time updates on the order status, estimated arrival time, an interactive map URL showing the delivery progress, and a notification message to display to the user.

Ensure the status is concise (e.g., "en route", "delivered"). The estimated arrival time should be a human-readable string.  The map URL should point to a live map.
`,
});

const getDeliveryUpdateFlow = ai.defineFlow(
  {
    name: 'getDeliveryUpdateFlow',
    inputSchema: GetDeliveryUpdateInputSchema,
    outputSchema: GetDeliveryUpdateOutputSchema,
  },
  async input => {
    // Here you would typically call an external API to get real-time delivery information.
    // For this example, we'll mock the data.

    // Mock external API call (replace with actual API call)
    const deliveryData = await getDeliveryData(input.orderId, input.deliveryVehicleId);

    const promptInput = {
      ...input,
      ...deliveryData,
    };

    const {output} = await deliveryUpdatePrompt(promptInput);
    return output!;
  }
);

async function getDeliveryData(orderId: string, deliveryVehicleId: string) {
  // Simulate fetching delivery data from an external API.
  // In a real application, replace this with an actual API call.
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({
        status: 'en route',
        estimatedArrivalTime: '20 minutes',
        mapUrl: 'https://example.com/map/' + deliveryVehicleId,
        notificationMessage: `Your order (ID: ${orderId}) is en route and will arrive in approximately 20 minutes. Track it here: https://example.com/map/${deliveryVehicleId}`,
      });
    }, 500);
  });
}
